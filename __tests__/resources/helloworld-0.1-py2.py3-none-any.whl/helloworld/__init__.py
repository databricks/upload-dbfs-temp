class Hello(object):
    def say_hello(self):
        return "Hello, World!"